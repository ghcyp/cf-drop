export interface UploadRecord {
  id: number;
  slug: string;
  uploader: string;
  ctime: number;
  mtime?: number; // 新增：修改时间（可选）
  size: number;
  files: FileItem[];
  message: string;
}