/// <reference types="@rsbuild/core/types" />
