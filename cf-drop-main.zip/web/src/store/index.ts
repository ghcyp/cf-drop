import { createStore } from "jotai";

export const store = createStore();
