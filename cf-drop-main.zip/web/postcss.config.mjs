import UnoCSS from '@unocss/postcss';

export default {
  plugins: [UnoCSS()],
};
